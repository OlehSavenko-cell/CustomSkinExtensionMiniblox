const skins = [
  "alice", "bob", "techno", "thebiggelo", "corrupted", "diana", "strange", "endoskeleton",
  "ganyu", "georgenotfound", "holly", "hutao", "jake", "james", "klee", "kyoko",
  "adele", "chris", "deadpool", "galactus", "heather", "ironman", "suit", "levi", "lexi",
  "natalie", "remus", "sara", "transformer", "vindicate", "adventure", "aether", "apex",
  "ariel", "aurora", "celeste", "cody", "ember", "finn", "glory", "hunter", "katie",
  "nova", "panda", "raven", "seraphina", "vain", "zane"
];

// スキンリスト追加
const skinSelect = document.getElementById("skinSelect");
skins.forEach(name => {
  const option = document.createElement("option");
  option.value = name;
  option.textContent = name;
  skinSelect.appendChild(option);
});

document.getElementById("appelyBtn").addEventListener("click", () => {
  const skinName = document.getElementById("skinSelect").value;
  const customUrl = document.getElementById("customUrl").value.trim();
  const file = document.getElementById("fileInput").files[0];

  const shouldReset = !skinName && !customUrl && !file;

  if (shouldReset) {
    chrome.runtime.sendMessage({ type: "resetSkin" }, () => {
      document.getElementById("status").textContent = "Skin reset successfully.";
    });
  } else {
    if (!skinName) {
      alert("Please select a skin");
      return;
    }

    if (file) {
      const reader = new FileReader();
      reader.onload = function(event) {
        sendSkinChange(skinName, event.target.result);
      };
      reader.readAsDataURL(file);
    } else {
      sendSkinChange(skinName, customUrl || null);
    }
  }
});

function sendSkinChange(skinName, url) {
  chrome.runtime.sendMessage({
    type: "setSkin",
    skinName: skinName,
    customUrl: url
  }, () => {
    document.getElementById("status").textContent = "Skin applied successfully.";
  });
}

