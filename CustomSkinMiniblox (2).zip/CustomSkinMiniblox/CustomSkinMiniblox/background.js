chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ currentSkins: {} });
});

//
function getRuleIdForSkin(skinName) {
  const skins = [
    "alice", "bob", "techno", "thebiggelo", "corrupted", "diana", "strange", "endoskeleton",
    "ganyu", "georgenotfound", "holly", "hutao", "jake", "james", "klee", "kyoko",
    "adele", "chris", "deadpool", "galactus", "heather", "ironman", "suit", "levi", "lexi",
    "natalie", "remus", "sara", "transformer", "vindicate", "adventure", "aether", "apex",
    "ariel", "aurora", "celeste", "cody", "ember", "finn", "glory", "hunter", "katie",
    "nova", "panda", "raven", "seraphina", "vain", "zane"
  ];
  const index = skins.indexOf(skinName);
  if (index === -1) {
    throw new Error(`Unknown skin name: ${skinName}`);
  }
  return 1000 + index; 
}

async function updateSkin(skinName, customUrl = null) {
  const originalUrl = `https://miniblox.io/textures/entity/skins/${skinName}.png`;
  const urlToRedirect = customUrl ? customUrl : originalUrl;
  const ruleId = getRuleIdForSkin(skinName);

  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: [ruleId],  //
    addRules: [{
      id: ruleId,
      priority: 1,
      action: {
        type: "redirect",
        redirect: { url: urlToRedirect }
      },
      condition: {
        urlFilter: `https://miniblox.io/textures/entity/skins/${skinName}.png*`,
        resourceTypes: ["image"]
      }
    }]
  });

  // 
  chrome.storage.local.get(["currentSkins"], (data) => {
    const currentSkins = data.currentSkins || {};
    currentSkins[skinName] = urlToRedirect;
    chrome.storage.local.set({ currentSkins });
  });
}

//
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "setSkin") {
    updateSkin(message.skinName, message.customUrl)
      .then(() => sendResponse())
      .catch((err) => {
        console.error(err);
        sendResponse();
      });
    return true; // async対応
  } else if (message.type === "resetSkin") {
    chrome.storage.local.get(["currentSkins"], async (data) => {
      const currentSkins = data.currentSkins || {};

      const ruleIds = Object.keys(currentSkins).map(name => getRuleIdForSkin(name));
      await chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: ruleIds
      });

      chrome.storage.local.set({ currentSkins: {} });
      sendResponse();
    });
    return true; // async対応
  }
});

